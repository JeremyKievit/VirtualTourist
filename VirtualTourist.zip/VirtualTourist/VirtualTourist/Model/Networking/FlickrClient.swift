//
//  FlickrClient.swift
//  VirtualTourist
//
//  Created by admin on 12/20/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import Foundation

class FlickrClient {
    
    struct Auth {
        static var APIKey: String = "470a2895859806359270134c72a52ac0"
    }
    
    enum Endpoints {
        static let searchPhotosBase = "https://www.flickr.com/services/rest/?method=flickr.photos.search"
        static let imageURLBase = "https://live.staticflickr.com/"
        
        case getSearcehdPhotos(String, Double, Double, Int, Int)
        case imageURL(String, String, String)
        
        var stringValue: String {
            switch self {
            case .getSearcehdPhotos(let APIKey, let lat, let lon, let radius, let page):
                return Endpoints.searchPhotosBase + "&api_key=\(APIKey)&lat=\(lat)&lon=\(lon)&radius=\(radius)&page=\(page)&format=json&nojsoncallback=1"
            case .imageURL(let server, let id, let secret):
                return Endpoints.imageURLBase + "\(server)/\(id)_\(secret)_q.jpg"
            }
        }
        
        var url: URL {
            return URL(string: stringValue)!
        }
    }
    
    class func retrieveFlickrImages(withCoordinates lat: Double, _ long: Double, radius: Int = 5, page: Int = 1, completion: @escaping (_ data: Photos?, _
        ImageURLs: [URL]?, _ error: Error?) -> Void) {
        
        var request = URLRequest(url: Endpoints.getSearcehdPhotos(Auth.APIKey, lat, long, radius, page).url)
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data else { completion(nil, nil, error); return }
            do {
                let decoder = JSONDecoder()
                let responseObject = try decoder.decode(FlickrSearchResponse.self, from: data)
                let pages = responseObject.photos
                
                var imageURLs = [URL]()
                let photos = responseObject.photos.photo
                for photo in photos {
                    let url = Endpoints.imageURL(photo.server ?? "", photo.id ?? "", photo.secret!).url
                    imageURLs.append(url)
                }
                
                completion(pages, imageURLs, nil)
            } catch {
               completion(nil, nil, error)
            }
        }
        task.resume()
    }
    
    class func downloadFlickrImages(imageURL: URL, completion: @escaping (_ data: Data?, _ error: Error?)->Void) {
        let task = URLSession.shared.dataTask(with: imageURL) { (data, response, error) in
        guard let data = data else { completion(nil, error); return }
        
        completion(data, nil)
      }
      task.resume()
    }
}
