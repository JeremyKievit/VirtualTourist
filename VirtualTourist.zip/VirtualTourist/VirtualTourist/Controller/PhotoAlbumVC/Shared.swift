//
//  PhotoAlbumVC+Extensions.swift
//  VirtualTourist
//
//  Created by admin on 1/2/21.
//  Copyright © 2021 Com.JeremyKievit. All rights reserved.
//

import Foundation
import UIKit
import CoreData

extension PhotoAlbumVC {
    func setCollectionState() {
        if noImages {
            newCollectionButton.setTitle("", for: .normal)
            noImagesLabel.text = "No Images at this Location"
            return
        }
        if currentPage == 1 {
            setUpFetchedResultsController()
        }
        if currentPage == selectedAnnotation.pages {
            DispatchQueue.main.async {
                self.newCollectionButton.setTitle("Reload Images", for: .normal)
                self.newCollectionButton.isEnabled = true
            }
        } else if currentPage < selectedAnnotation.pages {
            DispatchQueue.main.async {
                self.newCollectionButton.setTitle("\(self.currentPage)/\(self.selectedAnnotation.pages)  Next Page:  \(self.currentPage + 1)/\(self.selectedAnnotation.pages)", for: .normal)
                self.newCollectionButton.isEnabled = true
            }
        }

        for _ in imageURLs {
            let flickrImage = FlickrImage(context: self.dataController.viewContext)
            flickrImage.annotation = self.selectedAnnotation
            DispatchQueue.main.async {
                try? self.dataController.viewContext.save()
            }
        }
     }
}

// MARK: Collection view delegate
 
extension PhotoAlbumVC: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if noImages == false {
            return self.fetchedResultsController.sections![section].numberOfObjects
        } else {
            return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: self.cellReuseIdentifier, for: indexPath as IndexPath) as! ImageViewCell
        
        if let data = self.fetchedResultsController.object(at: indexPath).data {
            cell.imageView.image = UIImage(data: data)
        } else if self.noImages == false {
            if let url = self.imageURLs[indexPath.row] {
                DispatchQueue.main.async {
                    cell.activityIndicator.startAnimating()
                    cell.imageView.image = UIImage(named: "placeholder")
                }
                FlickrClient.downloadFlickrImages(imageURL: url) { data, error in
                    guard let data = data else { return }
                    self.fetchedResultsController.object(at: indexPath).data = data
                    try? self.dataController.viewContext.save()
                    DispatchQueue.main.async {
                        cell.activityIndicator.stopAnimating()
                        cell.imageView.image = UIImage(data: data)
                    }
                }
            }
        }

        return cell
    }
    
    // MARK: Delete images
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        deleteImage(at: indexPath)
    }
    
    func deleteImage(at indexPath: IndexPath) {
        let imageToDelete = fetchedResultsController.object(at: indexPath)
        dataController.viewContext.delete(imageToDelete)
        try? dataController.viewContext.save()
    }
}
 
// MARK: Fetched results controller delegate
 
extension PhotoAlbumVC: NSFetchedResultsControllerDelegate {
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        blockOperation = BlockOperation()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .insert:
            blockOperation.addExecutionBlock {
                if (newIndexPath != nil) {
                    DispatchQueue.main.async {
                        self.photoAlbumCollectionView.insertItems(at: [newIndexPath!])
                    }
                }
            }
        case .delete:
            blockOperation.addExecutionBlock {
                if ((indexPath != nil)) {
                    DispatchQueue.main.async {
                        self.photoAlbumCollectionView.deleteItems(at: [indexPath!])
                    }
                }
            }
        case .update:
            blockOperation.addExecutionBlock {
                if ((indexPath != nil)) {
                    DispatchQueue.main.async {
                        self.photoAlbumCollectionView.reloadItems(at: [newIndexPath!])
                    }
                }
            }
        default:
            break
        }
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        photoAlbumCollectionView?.performBatchUpdates({self.blockOperation.start()}, completion: nil)
    }
}
