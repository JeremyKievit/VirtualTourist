//
//  NewCollection.swift
//  VirtualTourist
//
//  Created by admin on 1/2/21.
//  Copyright © 2021 Com.JeremyKievit. All rights reserved.
//

import Foundation
import UIKit
import CoreData

extension PhotoAlbumVC {
    
    @IBAction func newCollection(_ sender: Any) {
            FlickrClient.retrieveFlickrImages(withCoordinates: selectedAnnotation.lat, selectedAnnotation.long, page: currentPage, completion: handleFlickrSearchResponse(data:imageURLs:error:))
    }

    func handleFlickrSearchResponse(data: Photos?, imageURLs: [URL]?, error: Error?) {
          guard let imageURLs = imageURLs else {
              DispatchQueue.main.async {
                  self.errorAlert(text: "Error", message: "Network request failed", action: "OK")
              }
              return
          }

          if imageURLs == [] {
              DispatchQueue.main.async {
                  self.newCollectionButton.setTitle("", for: .normal)
                  self.noImagesLabel.text = "No Images at this Location"
                  self.noImages = true
              }
          }

          self.imageURLs = []
          self.imageURLs = imageURLs

          if selectedAnnotation.pages == 1 {
              refreshCollection(title: "Reload Images")
          } else if currentPage < selectedAnnotation.pages {
              currentPage += 1
              refreshCollection(title: "\(currentPage)/\(selectedAnnotation.pages)  Next Page:  \(currentPage + 1)/\(selectedAnnotation.pages)")
          } else if currentPage == selectedAnnotation.pages {
              currentPage = 1
              refreshCollection(title: "Reset Collection")
          }
      }

    func refreshCollection(title: String) {
            DispatchQueue.main.async {
                self.newCollectionButton.setTitle("\(title)", for: .normal)
            }

    //        DispatchQueue.global(qos: .background).async {
    //        }

            if let fetchedObjects = self.fetchedResultsController.fetchedObjects {
                for flickrImage in fetchedObjects {
                    self.dataController.viewContext.delete(flickrImage)
                    DispatchQueue.main.async {
                        try? self.dataController.viewContext.save()
                    }
                }
            }

        //calling setCollectionState means 100% certainty that imageURLs contain 100% of the correct data
            setCollectionState()
        }
}


