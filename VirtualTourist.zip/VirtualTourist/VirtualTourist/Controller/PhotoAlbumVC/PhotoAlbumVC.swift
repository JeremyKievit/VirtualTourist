//
//  PhotoAlbumVC.swift
//  VirtualTourist
//
//  Created by admin on 12/19/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import Foundation
import UIKit
import CoreData
 
class PhotoAlbumVC: UIViewController {
    
    @IBOutlet weak var photoAlbumCollectionView: UICollectionView!
    @IBOutlet weak var newCollectionButton: UIButton!
    @IBOutlet weak var noImagesLabel: UILabel!
    
    let cellReuseIdentifier = "collectionViewCell"
    var selectedAnnotation: Annotation!
    var imageURLs: [URL?] = []
    var dataController: DataController!
    var fetchedResultsController: NSFetchedResultsController<FlickrImage>!
    var blockOperation = BlockOperation()
    var currentPage: Int = 1
    var noImages: Bool = false
    var hasData: Bool = false
    
    // MARK: View state
 
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        navigationController?.setNavigationBarHidden(false, animated: animated)
        
        newCollectionButton.isEnabled = false
        noImagesLabel.text = ""
        photoAlbumCollectionView.bounces = false
        
        setCollectionState()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        fetchedResultsController = nil
        noImagesLabel.text = ""
    }
       
    func setUpFetchedResultsController() {
        let fetchRequest: NSFetchRequest<FlickrImage> = FlickrImage.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "annotation", ascending: false)
        let predicate = NSPredicate(format: "annotation == %@", selectedAnnotation)

        fetchRequest.sortDescriptors = [sortDescriptor]
        fetchRequest.predicate = predicate

        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "flickrImages")
        fetchedResultsController.delegate = self
        do {
            try fetchedResultsController.performFetch()
            photoAlbumCollectionView.reloadData()
        } catch {
            DispatchQueue.main.async {
               self.errorAlert(text: "Error", message: "Coult not retrieve Flickr images", action: "OK")
            }
        }
   }
    
    // MARK: Dismiss collection button
    
    @IBAction func dismiss(_ sender: Any) {
        noImages = false
        self.presentingViewController?.dismiss(animated: true, completion: nil)
    }
}
